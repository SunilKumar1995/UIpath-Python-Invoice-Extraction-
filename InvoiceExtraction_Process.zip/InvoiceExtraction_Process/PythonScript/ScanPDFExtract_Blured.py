# -*- coding: utf-8 -*-
"""
Created on Tue Jan  7 23:39:05 2020

@author: sunil
"""

from PIL import Image
import pytesseract 
import re
import sys 
from pdf2image import convert_from_path 
import os,datetime
import cv2
import glob
from shutil import copyfile

from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)

#path of the PDF
#PDF_file="TVS invoice 2018141042.pdf"
#PDF_file="RM Invoices 6_1.pdf"
#PDF_file="RM Invoices 6_2.pdf"
#PDF_file="RM Invoices 6_3.pdf"
#PDF_file="E:\ML Project\TVS_Motor_POC\Input\RM Invoices 6_1.pdf"

inputpth="E:\ML Project\TVS_Motor_POC\Input"
# tempPath="E:\ML Project\TVS_Motor_POC\TempPeocess\"
OutPutPath="E:\ML Project\TVS_Motor_POC\OutPut"
files = glob.glob(os.path.join(inputpth, '*.pdf'))
#newfile=os.path.join(pth,filename+'_2'+extension)
try:
    
    for f in files:
        PDF_file=f
        #print("File Name"+PDF_file)
        #outputextfile = os.path.splitext(PDF_file)[0]
        extension = os.path.splitext(PDF_file)[1]
        basefilename=os.path.basename(os.path.splitext(PDF_file)[0])
        outputextfile =os.path.join(OutPutPath,basefilename+".txt")
        print(outputextfile)
   
    # Store all the pages of the PDF in a variable

        pages = convert_from_path(PDF_file, 500)
 
        image_counter = 1
    # Iterate through all the pages stored above
        for page in pages: 
   
            filename = "page_"+str(image_counter)+".jpg"
            page.save(filename, 'JPEG')  
            image_counter = image_counter + 1
  
 
        #Recognizing text from the images using OCR

        filelimit = image_counter-1
        #Create Text File
        outfile = outputextfile
  
        # Open the file in append mode
        f = open(outfile, "a") 
  
        # Iterate from 1 to total number of pages
        for i in range(1, filelimit + 1): 
  
            filename = "page_"+str(i)+".jpg"
          
            # Recognize the text as string in image using pytesserct
            image = cv2.imread(filename)
            blurred = cv2.blur(image, (3,3))
            img = Image.fromarray(blurred)
            text = str(((pytesseract.image_to_string(img, lang='eng'))))
            #text = str(((pytesseract.image_to_string(Image.open(filename))))) 
            # text = text.replace('-\n', '')
            text = text.replace('-\n', '')
            addpageNo = "########==========================="+str(i)+"Page==================*****************"
            if str(i)!="1":
                f.write(addpageNo)    
            f.write(text) 
        f.close() 
        print("Complete")
except Exception as e:
    print("Error in file Reading:="+ e)
    

#output_folder="E:\ML Project\ScanPDF Extract\OP"
# Find File Name
#extension = os.path.splitext(PDF_file)[1]

'''
#=======================For Invoice 2 Data Extract==================================
InvoiceNo = re.findall("\w{1}/\w{2}/\d{4}",text)[0]
InvoiceDate=text[text.index('Invoice Date >:')+len('Invoice Date >:'):text.index('Cespatch')]
PONo=text[text.index('PO No & Date :')+len('PO No & Date :'):text.index('LR No & Date')]
print(InvoiceNo)
print(InvoiceDate)
print(PONo)
'''

'''
#=======================For Invoice 3 Data Extract==================================
#InvoiceNo = re.findall("\w{1}/\w{2}/\d{4}",text)[0]

InvoiceNo =text[text.index('No:-')+len('No:-'):text.index('2AN :')].replace(" ","").strip()
InvoiceDate=text[text.index('Date :')+len('Date :'):text.index('Time')].replace("ne","").replace(" ","").strip()
PONo=text[text.index("Customer's Order No, > ")+len("Customer's Order No, > "):text.index('Mode Of Transport')].replace(" ","").strip()
print(InvoiceNo)
print(InvoiceDate)
print(PONo)
'''
'''
#=======================For Invoice 6 Data Extract==================================
#InvoiceNo = re.findall("\w{1}/\w{2}/\d{4}",text)[0]
InvoiceNo = re.findall("\d{3} \d{2}-\D{3}-\d{4}",text)[0]
#InvoiceNo =text[text.index('')+len('Estate ,'):text.index('Saru Section Road')].strip()
InvoiceDate=re.findall("\d{3} \d{2}-\D{3}-\d{4}",text)[0]
PONo=text[text.index("PERUMALPATTI ROAD, O ")+len("PERUMALPATTI ROAD, O"):text.index('VELLARIPPATTILMELUR')].replace(" ","").strip()
#PONo=re.split("|",PONo)[0].strip()
print(InvoiceNo)
print(InvoiceDate)
print(PONo)
'''

'''
#=======================For TVS Invoice Data Extract==================================
#InvoiceNo = re.findall("INDIEN \d{10}",text)[0]
InvoiceNo =text[text.index('Vellaripatti Melur Taluk')+len('Vellaripatti Melur Taluk'):text.index('625122 MADURAI')].replace(" ","").strip()
InvoiceDate=text[text.index('Vellaripatti Melur Taluk')+len('Vellaripatti Melur Taluk'):text.index('625122 MADURAI')].replace(" ","").strip()
#PONo=re.search("INDIEN \d{10}",text)[0]
#PONo=re.match("\D{7}\d{10}",text)[0]
PONo=text[text.index("Reference no./Date")+len("Reference no./Date"):text.index('Delivery note no./Date')].strip()
print(InvoiceNo)
print(InvoiceDate)
print(PONo)
'''
'''
outfile = "Invoice_File.txt"
f = open(outfile, "a")
#f.write("===========================RM TVS Invoices ============\n")
#f.write("===========================Invoices 6 ============\n")
#f.write("===========================Invoices 3 ============\n")
f.write("===========================TVS Invoices 2 ============\n")
f.write("Invoice No:"+InvoiceNo+"\n")
f.write("Invoice Date:"+InvoiceDate+"\n")
f.write("PO No:"+PONo+"\n")
f.close() 
print("Complete")
'''
