# -*- coding: utf-8 -*-
"""
Created on Tue Jan  7 23:39:05 2020

@author: sunil
"""

import os
import sys
import cv2
from PIL import Image
from pytesseract import image_to_string

#from pdf2image import convert_from_path

def image_with_blur(FileName):
    images = cv2.imread(FileName)
    bullred =cv2.blur(images,(3,3))
    #cv2.imshow("image",bullred)
    #cv2.waitKey(0)
    img = Image.fromarray(bullred)
    #text=str(((image_to_string(Image.open(FileName)))))
    text = str(image_to_string(img, lang="eng"))
    return text


def image_without_blur(FileName):
    text = str(((image_to_string(Image.open(FileName)))))
    return text

if __name__ == '__main__':
    #print(image_with_blur("4.png"))
    print(image_without_blur("4.png"))
